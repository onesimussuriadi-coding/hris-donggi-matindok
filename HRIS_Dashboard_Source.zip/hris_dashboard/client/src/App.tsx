import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import DashboardLayout from "@/components/DashboardLayout";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Company from "./pages/Company";
import Positions from "./pages/Positions";
import Employees from "./pages/Employees";
import Shifts from "./pages/Shifts";
import Attendance from "./pages/Attendance";
import Overtime from "./pages/Overtime";
import Allowances from "./pages/Allowances";
import Payroll from "./pages/Payroll";
import Payslips from "./pages/Payslips";
import SettingsPage from "./pages/SettingsPage";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/company" component={Company} />
        <Route path="/positions" component={Positions} />
        <Route path="/employees" component={Employees} />
        <Route path="/shifts" component={Shifts} />
        <Route path="/attendance" component={Attendance} />
        <Route path="/overtime" component={Overtime} />
        <Route path="/allowances" component={Allowances} />
        <Route path="/payroll" component={Payroll} />
        <Route path="/payslips" component={Payslips} />
        <Route path="/settings" component={SettingsPage} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
