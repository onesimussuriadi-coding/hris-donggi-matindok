import { useMemo } from "react";
import { trpc } from "@/lib/trpc";
import CrudTable from "@/components/CrudTable";

export default function Positions() {
  const { data, isLoading } = trpc.position.list.useQuery();
  const { data: divisions } = trpc.division.list.useQuery();
  const createMut = trpc.position.create.useMutation();
  const updateMut = trpc.position.update.useMutation();
  const deleteMut = trpc.position.delete.useMutation();
  const utils = trpc.useUtils();

  const divMap = useMemo(() => {
    const m: Record<number, string> = {};
    (divisions || []).forEach(d => { m[d.id] = d.name; });
    return m;
  }, [divisions]);

  const divOptions = (divisions || []).map(d => ({ value: String(d.id), label: d.name }));

  const processedData = (data || []).map((p: any) => ({
    ...p,
    divisionName: divMap[p.divisionId] || "-",
    baseSalaryFmt: p.baseSalary ? Number(p.baseSalary).toLocaleString('id-ID') : "-",
    positionAllowanceFmt: p.positionAllowance ? Number(p.positionAllowance).toLocaleString('id-ID') : "-",
  }));

  const fields = [
    { key: "name", label: "Nama Jabatan", required: true },
    { key: "divisionId", label: "Divisi", type: "select" as const, options: divOptions, required: true, hideInTable: true },
    { key: "divisionName", label: "Divisi", hideInForm: true },
    { key: "level", label: "Level/Grade" },
    { key: "baseSalary", label: "Gaji Pokok", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "baseSalaryFmt", label: "Gaji Pokok", hideInForm: true },
    { key: "positionAllowance", label: "Tunjangan Jabatan", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "positionAllowanceFmt", label: "Tunjangan Jabatan", hideInForm: true },
  ];

  return (
    <CrudTable
      title="Jabatan"
      description="Kelola data jabatan dan level kepegawaian"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["name", "level", "divisionName"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.position.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.position.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.position.list.invalidate(); }}
    />
  );
}
