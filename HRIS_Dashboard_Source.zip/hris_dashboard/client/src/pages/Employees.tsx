import { useMemo } from "react";
import { trpc } from "@/lib/trpc";
import CrudTable from "@/components/CrudTable";

export default function Employees() {
  const { data, isLoading } = trpc.employee.list.useQuery();
  const { data: divisions } = trpc.division.list.useQuery();
  const { data: positions } = trpc.position.list.useQuery();
  const createMut = trpc.employee.create.useMutation();
  const updateMut = trpc.employee.update.useMutation();
  const deleteMut = trpc.employee.delete.useMutation();
  const utils = trpc.useUtils();

  const divMap = useMemo(() => { const m: Record<number, string> = {}; (divisions || []).forEach(d => { m[d.id] = d.name; }); return m; }, [divisions]);
  const posMap = useMemo(() => { const m: Record<number, string> = {}; (positions || []).forEach(p => { m[p.id] = p.name; }); return m; }, [positions]);

  const divOptions = (divisions || []).map(d => ({ value: String(d.id), label: d.name }));
  const posOptions = (positions || []).map(p => ({ value: String(p.id), label: p.name }));

  const processedData = (data || []).map((e: any) => ({
    ...e,
    divisionName: divMap[e.divisionId] || "-",
    positionName: posMap[e.positionId] || "-",
    genderLabel: e.gender === "L" ? "Laki-laki" : e.gender === "P" ? "Perempuan" : "-",
    payrollLabel: e.payrollSystem === "monthly" ? "Bulanan" : e.payrollSystem === "daily" ? "Harian" : e.payrollSystem === "shift" ? "Shift" : "-",
    statusLabel: e.employmentStatus === "tetap" ? "Tetap" : e.employmentStatus === "kontrak" ? "Kontrak" : e.employmentStatus === "magang" ? "Magang" : e.employmentStatus === "harian" ? "Harian" : "-",
    activeLabel: e.isActive === "active" ? "Aktif" : "Resign",
    baseSalaryFmt: e.baseSalary ? Number(e.baseSalary).toLocaleString('id-ID') : "-",
    dailyWageFmt: e.dailyWage ? Number(e.dailyWage).toLocaleString('id-ID') : "-",
  }));

  const fields = [
    { key: "nik", label: "NIK", required: true },
    { key: "name", label: "Nama Lengkap", required: true },
    { key: "gender", label: "Jenis Kelamin", type: "select" as const, options: [{ value: "L", label: "Laki-laki" }, { value: "P", label: "Perempuan" }], hideInTable: true },
    { key: "genderLabel", label: "L/P", hideInForm: true },
    { key: "birthPlace", label: "Tempat Lahir", hideInTable: true },
    { key: "birthDate", label: "Tanggal Lahir", type: "date" as const, hideInTable: true },
    { key: "address", label: "Alamat", type: "textarea" as const, hideInTable: true },
    { key: "phone", label: "Telepon", hideInTable: true },
    { key: "email", label: "Email", hideInTable: true },
    { key: "divisionId", label: "Divisi", type: "select" as const, options: divOptions, hideInTable: true },
    { key: "divisionName", label: "Divisi", hideInForm: true },
    { key: "positionId", label: "Jabatan", type: "select" as const, options: posOptions, hideInTable: true },
    { key: "positionName", label: "Jabatan", hideInForm: true },
    { key: "hireDate", label: "Tanggal Masuk", type: "date" as const, required: true, hideInTable: true },
    { key: "employmentStatus", label: "Status Kepegawaian", type: "select" as const, options: [{ value: "tetap", label: "Tetap" }, { value: "kontrak", label: "Kontrak" }, { value: "magang", label: "Magang" }, { value: "harian", label: "Harian" }], hideInTable: true },
    { key: "statusLabel", label: "Status", hideInForm: true },
    { key: "payrollSystem", label: "Sistem Penggajian", type: "select" as const, options: [{ value: "monthly", label: "Bulanan" }, { value: "daily", label: "Harian" }, { value: "shift", label: "Shift" }], required: true, hideInTable: true },
    { key: "payrollLabel", label: "Sistem Gaji", hideInForm: true },
    { key: "baseSalary", label: "Gaji Pokok (Bulanan)", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "baseSalaryFmt", label: "Gaji Pokok", hideInForm: true },
    { key: "dailyWage", label: "Upah Harian", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "dailyWageFmt", label: "Upah Harian", hideInForm: true },
    { key: "ptkpStatus", label: "Status PTKP (PPh21)", type: "select" as const, options: [{ value: "TK0", label: "TK0 (Tidak Kawan, 0 tanggungan)" }, { value: "K0", label: "K0 (Kawin, 0 tanggungan)" }, { value: "K1", label: "K1 (Kawin, 1 tanggungan)" }, { value: "K2", label: "K2 (Kawin, 2 tanggungan)" }, { value: "K3", label: "K3 (Kawin, 3 tanggungan)" }], hideInTable: true },
    { key: "bpjsKes", label: "No. BPJS Kesehatan", hideInTable: true },
    { key: "bpjsTk", label: "No. BPJS Ketenagakerjaan", hideInTable: true },
    { key: "npwp", label: "NPWP", hideInTable: true },
    { key: "bank", label: "Bank", hideInTable: true },
    { key: "bankAccount", label: "No. Rekening", hideInTable: true },
    { key: "isActive", label: "Status Karyawan", type: "select" as const, options: [{ value: "active", label: "Aktif" }, { value: "resigned", label: "Resign" }], hideInTable: true },
    { key: "activeLabel", label: "Status", hideInForm: true },
  ];

  return (
    <CrudTable
      title="Data Karyawan"
      description="Kelola data karyawan dengan sistem penggajian bulanan, harian, dan shift"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["nik", "name", "divisionName", "positionName"]}
      filterField="payrollLabel"
      filterOptions={[{ value: "Bulanan", label: "Bulanan" }, { value: "Harian", label: "Harian" }, { value: "Shift", label: "Shift" }]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.employee.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.employee.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.employee.list.invalidate(); }}
    />
  );
}
