import { trpc } from "@/lib/trpc";
import CrudTable from "@/components/CrudTable";

export default function Shifts() {
  const { data, isLoading } = trpc.shift.list.useQuery();
  const createMut = trpc.shift.create.useMutation();
  const updateMut = trpc.shift.update.useMutation();
  const deleteMut = trpc.shift.delete.useMutation();
  const utils = trpc.useUtils();

  const processedData = (data || []).map((s: any) => ({
    ...s,
    incentiveFmt: s.shiftIncentive ? Number(s.shiftIncentive).toLocaleString('id-ID') : "-",
  }));

  const fields = [
    { key: "name", label: "Nama Shift", required: true, placeholder: "Contoh: Shift Pagi" },
    { key: "startTime", label: "Jam Mulai", required: true, placeholder: "Contoh: 08:00" },
    { key: "endTime", label: "Jam Selesai", required: true, placeholder: "Contoh: 16:00" },
    { key: "workDays", label: "Hari Kerja", placeholder: "1,2,3,4,5 (Senin-Jumat)" },
    { key: "shiftIncentive", label: "Insentif Shift", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "incentiveFmt", label: "Insentif", hideInForm: true },
    { key: "description", label: "Deskripsi", type: "textarea" as const, hideInTable: true },
  ];

  return (
    <CrudTable
      title="Data Shift"
      description="Kelola jadwal shift kerja karyawan beserta insentif"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["name", "startTime", "endTime"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.shift.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.shift.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.shift.list.invalidate(); }}
    />
  );
}
