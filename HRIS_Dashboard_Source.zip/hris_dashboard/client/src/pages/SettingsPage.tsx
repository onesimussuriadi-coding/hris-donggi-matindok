import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Save, Settings as SettingsIcon } from "lucide-react";
import { toast } from "sonner";

export default function SettingsPage() {
  const { data, isLoading } = trpc.settings.list.useQuery();
  const upsertMut = trpc.settings.upsert.useMutation();
  const utils = trpc.useUtils();

  const [values, setValues] = useState<Record<string, string>>({});

  useEffect(() => {
    if (data) {
      const m: Record<string, string> = {};
      data.forEach((s: any) => { m[s.key] = s.value; });
      setValues(m);
    }
  }, [data]);

  const settingGroups = [
    {
      title: "BPJS Kesehatan",
      settings: [
        { key: "bpjs_kes_employee_pct", label: "Iuran Karyawan (%)", placeholder: "1.0" },
        { key: "bpjs_kes_employer_pct", label: "Iuran Perusahaan (%)", placeholder: "4.0" },
        { key: "bpjs_kes_max_salary", label: "Batas Maksimal Gaji", placeholder: "12000000" },
      ],
    },
    {
      title: "BPJS Ketenagakerjaan",
      settings: [
        { key: "bpjs_tk_jht_employee_pct", label: "JHT Karyawan (%)", placeholder: "2.0" },
        { key: "bpjs_tk_jht_employer_pct", label: "JHT Perusahaan (%)", placeholder: "3.7" },
        { key: "bpjs_tk_jkk_pct", label: "JKK Perusahaan (%)", placeholder: "0.24" },
        { key: "bpjs_tk_jkm_pct", label: "JKM Perusahaan (%)", placeholder: "0.3" },
        { key: "bpjs_tk_jp_employee_pct", label: "JP Karyawan (%)", placeholder: "1.0" },
        { key: "bpjs_tk_jp_employer_pct", label: "JP Perusahaan (%)", placeholder: "2.0" },
        { key: "bpjs_tk_jp_max_salary", label: "Batas Maksimal Gaji JP", placeholder: "10075500" },
      ],
    },
    {
      title: "PPh 21 (PTKP)",
      settings: [
        { key: "ptkp_tk0", label: "TK0", placeholder: "54000000" },
        { key: "ptkp_k0", label: "K0", placeholder: "58500000" },
        { key: "ptkp_k1", label: "K1", placeholder: "63000000" },
        { key: "ptkp_k2", label: "K2", placeholder: "67500000" },
        { key: "ptkp_k3", label: "K3", placeholder: "72000000" },
      ],
    },
    {
      title: "Tarif PPh 21 Progresif",
      settings: [
        { key: "pph21_layer_1", label: "Layer 1 (0-60jt): 5%", placeholder: "50000000:0.05" },
        { key: "pph21_layer_2", label: "Layer 2 (60-250jt): 15%", placeholder: "190000000:0.15" },
        { key: "pph21_layer_3", label: "Layer 3 (250-500jt): 25%", placeholder: "250000000:0.25" },
        { key: "pph21_layer_4", label: "Layer 4 (500jt-5M): 30%", placeholder: "4500000000:0.30" },
        { key: "pph21_layer_5", label: "Layer 5 (>5M): 35%", placeholder: "0:0.35" },
      ],
    },
    {
      title: "Lembur (Overtime)",
      settings: [
        { key: "ot_hourly_rate", label: "Tarif per Jam (1x)", placeholder: "0" },
        { key: "ot_workday_multiplier", label: "Pengali Hari Kerja", placeholder: "1.5" },
        { key: "ot_holiday_multiplier", label: "Pengali Hari Libur", placeholder: "2.0" },
        { key: "ot_major_holiday_multiplier", label: "Pengali Hari Besar", placeholder: "3.0" },
      ],
    },
    {
      title: "Umum",
      settings: [
        { key: "work_days_per_month", label: "Hari Kerja per Bulan", placeholder: "22" },
        { key: "default_currency", label: "Mata Uang", placeholder: "IDR" },
      ],
    },
  ];

  const save = () => {
    settingGroups.forEach(group => {
      group.settings.forEach(s => {
        if (values[s.key] !== undefined) {
          (upsertMut.mutate as any)({ key: s.key, value: values[s.key], description: s.label });
        }
      });
    });
    utils.settings.list.invalidate();
    toast.success("Pengaturan tersimpan");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Pengaturan</h1>
          <p className="text-sm text-muted-foreground mt-1">Konfigurasi BPJS, PPh21, tarif lembur, dan parameter payroll</p>
        </div>
        <Button onClick={save} className="gap-2"><Save className="h-4 w-4" />Simpan Pengaturan</Button>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Memuat pengaturan...</div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {settingGroups.map(group => (
            <Card key={group.title} className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <SettingsIcon className="h-4 w-4 text-primary" />
                  {group.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {group.settings.map(s => (
                  <div key={s.key}>
                    <Label className="text-sm font-medium">{s.label}</Label>
                    <Input
                      className="mt-1.5"
                      placeholder={s.placeholder}
                      value={values[s.key] || ""}
                      onChange={e => setValues(prev => ({ ...prev, [s.key]: e.target.value }))}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
