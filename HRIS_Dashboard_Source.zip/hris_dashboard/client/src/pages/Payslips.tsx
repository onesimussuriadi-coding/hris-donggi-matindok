import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { FileText, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Payslips() {
  const { data: periods } = trpc.payrollPeriod.list.useQuery();
  const { data: employees } = trpc.employee.list.useQuery();
  const { data: companies } = trpc.company.list.useQuery();
  const { data: positions } = trpc.position.list.useQuery();
  const [selectedPeriod, setSelectedPeriod] = useState<string>("");

  const { data: payrollItems, isLoading } = trpc.payrollItem.list.useQuery(
    { periodId: selectedPeriod ? parseInt(selectedPeriod) : undefined },
    { enabled: !!selectedPeriod }
  );

  const empMap = useMemo(() => { const m: Record<number, any> = {}; (employees || []).forEach(e => { m[e.id] = e; }); return m; }, [employees]);
  const positionMap = useMemo(() => { const m: Record<number, any> = {}; (positions || []).forEach(p => { m[p.id] = p; }); return m; }, [positions]);

  const formatRupiah = (val: any) => {
    const n = Number(val) || 0;
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n);
  };
  const escapeHtml = (value: unknown) => String(value ?? '').replace(/[&<>'"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  }[char] || char));

  const generatePayslipPDF = (item: any) => {
    const emp = empMap[item.employeeId];
    const company = companies?.[0];
    const details = item.details as any;

    const printWin = window.open('', '_blank');
    if (!printWin) { toast.error("Popup diblokir. Izinkan popup untuk mencetak slip gaji."); return; }

    const html = `
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Slip Gaji - ${escapeHtml(emp?.name)} - ${escapeHtml(periods?.find(p => p.id === parseInt(selectedPeriod))?.period)}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Arial', sans-serif; padding: 40px; color: #1a1a2e; }
  .slip { max-width: 800px; margin: 0 auto; border: 2px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
  .header { background: #1a1a2e; color: white; padding: 24px 32px; display: flex; justify-content: space-between; align-items: center; }
  .header h1 { font-size: 20px; font-weight: 700; }
  .header .company { font-size: 14px; opacity: 0.8; }
  .header .period { font-size: 12px; opacity: 0.7; }
  .employee-info { padding: 20px 32px; border-bottom: 1px solid #e0e0e0; display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .employee-info .row { display: flex; gap: 8px; font-size: 13px; }
  .employee-info .label { font-weight: 600; min-width: 100px; color: #666; }
  .employee-info .value { font-weight: 500; }
  .section { padding: 20px 32px; }
  .section h2 { font-size: 14px; font-weight: 700; margin-bottom: 12px; color: #1a1a2e; border-bottom: 2px solid #1a1a2e; padding-bottom: 4px; }
  .item-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; }
  .item-row .label { color: #444; }
  .item-row .amount { font-weight: 500; }
  .total-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; font-weight: 700; border-top: 2px solid #1a1a2e; margin-top: 8px; }
  .take-home { background: #f0f4ff; padding: 20px 32px; display: flex; justify-content: space-between; align-items: center; }
  .take-home .label { font-size: 16px; font-weight: 700; }
  .take-home .amount { font-size: 24px; font-weight: 800; color: #1a40af; }
  .footer { padding: 16px 32px; font-size: 11px; color: #999; text-align: center; border-top: 1px solid #e0e0e0; }
  .columns { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
  @media print { body { padding: 0; } .slip { border: none; } }
</style>
</head>
<body>
<div class="slip">
  <div class="header">
    <div>
      <h1>SLIP GAJI</h1>
      <div class="company">${escapeHtml(company?.name || 'Perusahaan')}</div>
    </div>
    <div style="text-align: right;">
      <div class="period">Periode: ${escapeHtml(periods?.find(p => p.id === parseInt(selectedPeriod))?.period || '-')}</div>
      <div class="period">Status: ${escapeHtml(periods?.find(p => p.id === parseInt(selectedPeriod))?.status || '-')}</div>
    </div>
  </div>

  <div class="employee-info">
    <div class="row"><span class="label">NIK</span><span class="value">${escapeHtml(emp?.nik || '-')}</span></div>
    <div class="row"><span class="label">Nama</span><span class="value">${escapeHtml(emp?.name || '-')}</span></div>
    <div class="row"><span class="label">Jabatan</span><span class="value">${escapeHtml(positionMap[emp?.positionId]?.name || '-')}</span></div>
    <div class="row"><span class="label">Sistem</span><span class="value">${details?.payrollSystem === 'daily' ? 'Harian' : details?.payrollSystem === 'shift' ? 'Shift' : 'Bulanan'}</span></div>
    <div class="row"><span class="label">Hadir</span><span class="value">${details?.hadirCount || 0} hari</span></div>
    <div class="row"><span class="label">Shift</span><span class="value">${details?.shiftCount || 0} kali</span></div>
  </div>

  <div class="section">
    <div class="columns">
      <div>
        <h2>PENGHASILAN</h2>
        <div class="item-row"><span class="label">Gaji Pokok</span><span class="amount">${formatRupiah(item.baseSalary)}</span></div>
        <div class="item-row"><span class="label">Tunjangan Shift</span><span class="amount">${formatRupiah(item.shiftAllowance)}</span></div>
        <div class="item-row"><span class="label">Upah Lembur</span><span class="amount">${formatRupiah(item.overtimePay)}</span></div>
        ${(details?.allowanceDetails || []).map((a: any) => `<div class="item-row"><span class="label">${escapeHtml(a.name)}</span><span class="amount">${formatRupiah(a.amount)}</span></div>`).join('')}
        <div class="total-row"><span>Total Penghasilan</span><span>${formatRupiah(Number(item.baseSalary) + Number(item.totalAllowance))}</span></div>
      </div>
      <div>
        <h2>POTONGAN</h2>
        ${(details?.deductionDetails || []).map((d: any) => `<div class="item-row"><span class="label">${escapeHtml(d.name)}</span><span class="amount">${formatRupiah(d.amount)}</span></div>`).join('')}
        <div class="item-row"><span class="label">BPJS Kesehatan</span><span class="amount">${formatRupiah(item.bpjsKes)}</span></div>
        <div class="item-row"><span class="label">BPJS Ketenagakerjaan</span><span class="amount">${formatRupiah(item.bpjsTk)}</span></div>
        <div class="item-row"><span class="label">PPh 21</span><span class="amount">${formatRupiah(item.pph21)}</span></div>
        <div class="total-row"><span>Total Potongan</span><span>${formatRupiah(Number(item.totalDeduction) + Number(item.bpjsKes) + Number(item.bpjsTk) + Number(item.pph21))}</span></div>
      </div>
    </div>
  </div>

  <div class="take-home">
    <span class="label">TAKE HOME PAY</span>
    <span class="amount">${formatRupiah(item.takeHomePay)}</span>
  </div>

  <div class="footer">
    Slip gaji ini dihasilkan secara otomatis oleh sistem HRIS. Terima kasih.
  </div>
</div>
<script>window.onload = function() { window.print(); }</script>
</body>
</html>`;

    printWin.document.write(html);
    printWin.document.close();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Slip Gaji</h1>
        <p className="text-sm text-muted-foreground mt-1">Pilih periode untuk melihat dan mencetak slip gaji karyawan</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <FileText className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">Pilih Periode</CardTitle>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Pilih periode..." />
              </SelectTrigger>
              <SelectContent>
                {(periods || []).map(p => (
                  <SelectItem key={p.id} value={String(p.id)}>{p.period} ({p.status})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {!selectedPeriod ? (
            <div className="text-center py-12 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">Pilih periode penggajian untuk melihat slip gaji.</p>
            </div>
          ) : isLoading ? (
            <div className="flex items-center justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : !payrollItems || payrollItems.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground"><p className="text-sm">Belum ada data payroll untuk periode ini.</p></div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>NIK</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead className="text-right">Gaji Pokok</TableHead>
                    <TableHead className="text-right">Tunjangan</TableHead>
                    <TableHead className="text-right">Potongan</TableHead>
                    <TableHead className="text-right">PPh21</TableHead>
                    <TableHead className="text-right font-bold">Take Home</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payrollItems.map(item => {
                    const emp = empMap[item.employeeId];
                    return (
                      <TableRow key={item.id}>
                        <TableCell>{emp?.nik || "-"}</TableCell>
                        <TableCell className="font-medium">{emp?.name || "-"}</TableCell>
                        <TableCell className="text-right">{formatRupiah(item.baseSalary)}</TableCell>
                        <TableCell className="text-right">{formatRupiah(item.totalAllowance)}</TableCell>
                        <TableCell className="text-right">{formatRupiah(Number(item.totalDeduction) + Number(item.bpjsKes) + Number(item.bpjsTk))}</TableCell>
                        <TableCell className="text-right">{formatRupiah(item.pph21)}</TableCell>
                        <TableCell className="text-right font-bold text-primary">{formatRupiah(item.takeHomePay)}</TableCell>
                        <TableCell className="text-right">
                          <Button size="sm" variant="outline" onClick={() => generatePayslipPDF(item)} className="gap-1">
                            <Download className="h-3 w-3" />Cetak
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
