import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Loader2, Play, CheckCircle, DollarSign, Search } from "lucide-react";
import { toast } from "sonner";

const statusColors: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  submitted: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  paid: "bg-emerald-100 text-emerald-700",
};

const statusLabels: Record<string, string> = {
  draft: "Draft",
  submitted: "Submitted",
  approved: "Approved",
  paid: "Paid",
};

export default function Payroll() {
  const { data: periods, isLoading } = trpc.payrollPeriod.list.useQuery();
  const createMut = trpc.payrollPeriod.create.useMutation();
  const updateMut = trpc.payrollPeriod.update.useMutation();
  const processMut = trpc.payroll.process.useMutation();
  const utils = trpc.useUtils();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [periodInput, setPeriodInput] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  const { data: payrollItems } = trpc.payrollItem.list.useQuery(
    { periodId: selectedPeriod || undefined },
    { enabled: selectedPeriod !== null }
  );

  const { data: employees } = trpc.employee.list.useQuery();

  const empMap = useMemo(() => { const m: Record<number, any> = {}; (employees || []).forEach(e => { m[e.id] = e; }); return m; }, [employees]);

  const formatRupiah = (val: any) => {
    const n = Number(val) || 0;
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n);
  };

  const createPeriod = () => {
    if (!periodInput) { toast.error("Periode wajib diisi"); return; }
    (createMut.mutate as any)({ period: periodInput, status: "draft" });
    utils.payrollPeriod.list.invalidate();
    toast.success("Periode penggajian dibuat");
    setDialogOpen(false);
    setPeriodInput("");
  };

  const processPayroll = (periodId: number) => {
    (processMut.mutate as any)({ periodId });
    utils.payrollPeriod.list.invalidate();
    utils.payrollItem.list.invalidate();
    toast.success("Payroll sedang diproses...");
    setSelectedPeriod(periodId);
  };

  const approvePeriod = (periodId: number) => {
    (updateMut.mutate as any)({ id: periodId, status: "approved", approvedAt: new Date().toISOString() });
    utils.payrollPeriod.list.invalidate();
    toast.success("Periode disetujui");
  };

  const payPeriod = (periodId: number) => {
    (updateMut.mutate as any)({ id: periodId, status: "paid", paidAt: new Date().toISOString() });
    utils.payrollPeriod.list.invalidate();
    toast.success("Pembayaran payroll selesai");
  };

  const filteredPeriods = (periods || []).filter(p =>
    !search || p.period.includes(search)
  );

  const filteredItems = (payrollItems || []).filter(item => {
    if (!search) return true;
    const emp = empMap[item.employeeId];
    return emp?.name?.toLowerCase().includes(search.toLowerCase()) || emp?.nik?.includes(search);
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Penggajian (Payroll)</h1>
          <p className="text-sm text-muted-foreground mt-1">Proses penggajian dengan BPJS, PPh21, dan take home pay otomatis</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />Buat Periode
        </Button>
      </div>

      {/* Period List */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Periode Penggajian</CardTitle>
            <div className="relative w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Cari periode..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : filteredPeriods.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground"><p className="text-sm">Belum ada periode penggajian.</p></div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Periode</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Diproses</TableHead>
                    <TableHead>Disetujui</TableHead>
                    <TableHead>Dibayar</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPeriods.map(p => (
                    <TableRow key={p.id} className={selectedPeriod === p.id ? "bg-accent/50" : ""} onClick={() => setSelectedPeriod(p.id)} style={{ cursor: "pointer" }}>
                      <TableCell className="font-medium">{p.period}</TableCell>
                      <TableCell><Badge className={statusColors[p.status]} variant="secondary">{statusLabels[p.status]}</Badge></TableCell>
                      <TableCell>{p.processedAt ? new Date(p.processedAt).toLocaleDateString('id-ID') : "-"}</TableCell>
                      <TableCell>{p.approvedAt ? new Date(p.approvedAt).toLocaleDateString('id-ID') : "-"}</TableCell>
                      <TableCell>{p.paidAt ? new Date(p.paidAt).toLocaleDateString('id-ID') : "-"}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {p.status === "draft" && (
                            <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); processPayroll(p.id); }} className="gap-1">
                              <Play className="h-3 w-3" />Proses
                            </Button>
                          )}
                          {p.status === "submitted" && (
                            <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); approvePeriod(p.id); }} className="gap-1">
                              <CheckCircle className="h-3 w-3" />Setujui
                            </Button>
                          )}
                          {p.status === "approved" && (
                            <Button size="sm" onClick={(e) => { e.stopPropagation(); payPeriod(p.id); }} className="gap-1">
                              <DollarSign className="h-3 w-3" />Bayar
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payroll Items for Selected Period */}
      {selectedPeriod !== null && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Detail Payroll — Periode {(periods || []).find(p => p.id === selectedPeriod)?.period}</CardTitle>
          </CardHeader>
          <CardContent>
            {!payrollItems || payrollItems.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground"><p className="text-sm">Belum ada data payroll. Proses periode untuk menghasilkan slip gaji.</p></div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>NIK</TableHead>
                      <TableHead>Nama</TableHead>
                      <TableHead>Sistem</TableHead>
                      <TableHead className="text-right">Gaji Pokok</TableHead>
                      <TableHead className="text-right">Shift</TableHead>
                      <TableHead className="text-right">Lembur</TableHead>
                      <TableHead className="text-right">Tunjangan</TableHead>
                      <TableHead className="text-right">Potongan</TableHead>
                      <TableHead className="text-right">BPJS Kes</TableHead>
                      <TableHead className="text-right">BPJS TK</TableHead>
                      <TableHead className="text-right">PPh21</TableHead>
                      <TableHead className="text-right font-bold">Take Home</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredItems.map(item => {
                      const emp = empMap[item.employeeId];
                      const details = item.details as any;
                      return (
                        <TableRow key={item.id}>
                          <TableCell>{emp?.nik || "-"}</TableCell>
                          <TableCell className="font-medium">{emp?.name || "-"}</TableCell>
                          <TableCell>{details?.payrollSystem === "daily" ? "Harian" : details?.payrollSystem === "shift" ? "Shift" : "Bulanan"}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.baseSalary)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.shiftAllowance)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.overtimePay)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.totalAllowance)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.totalDeduction)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.bpjsKes)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.bpjsTk)}</TableCell>
                          <TableCell className="text-right">{formatRupiah(item.pph21)}</TableCell>
                          <TableCell className="text-right font-bold text-primary">{formatRupiah(item.takeHomePay)}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Buat Periode Penggajian</DialogTitle></DialogHeader>
          <div className="py-4">
            <label className="text-sm font-medium mb-1.5 block">Periode (Format: YYYY-MM) *</label>
            <Input placeholder="Contoh: 2026-07" value={periodInput} onChange={e => setPeriodInput(e.target.value)} />
            <p className="text-xs text-muted-foreground mt-2">Periode menentukan rentang absensi dan lembur yang dihitung untuk payroll.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Batal</Button>
            <Button onClick={createPeriod}>Buat</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
