import { useMemo } from "react";
import { trpc } from "@/lib/trpc";
import CrudTable from "@/components/CrudTable";

export default function Attendance() {
  const { data, isLoading } = trpc.attendance.list.useQuery();
  const { data: employees } = trpc.employee.list.useQuery();
  const createMut = trpc.attendance.create.useMutation();
  const updateMut = trpc.attendance.update.useMutation();
  const deleteMut = trpc.attendance.delete.useMutation();
  const utils = trpc.useUtils();

  const empMap = useMemo(() => { const m: Record<number, string> = {}; (employees || []).forEach(e => { m[e.id] = `${e.nik} - ${e.name}`; }); return m; }, [employees]);
  const empOptions = (employees || []).map(e => ({ value: String(e.id), label: `${e.nik} - ${e.name}` }));

  const processedData = (data || []).map((a: any) => ({
    ...a,
    employeeName: empMap[a.employeeId] || "-",
    dateFmt: a.date ? new Date(a.date).toLocaleDateString('id-ID') : "-",
  }));

  const fields = [
    { key: "employeeId", label: "Karyawan", type: "select" as const, options: empOptions, required: true, hideInTable: true },
    { key: "employeeName", label: "Karyawan", hideInForm: true },
    { key: "date", label: "Tanggal", type: "date" as const, required: true, hideInTable: true },
    { key: "dateFmt", label: "Tanggal", hideInForm: true },
    { key: "status", label: "Status", type: "select" as const, options: [{ value: "hadir", label: "Hadir" }, { value: "sakit", label: "Sakit" }, { value: "izin", label: "Izin" }, { value: "cuti", label: "Cuti" }, { value: "alpha", label: "Alpha" }], required: true },
    { key: "clockIn", label: "Jam Masuk", placeholder: "08:00" },
    { key: "clockOut", label: "Jam Keluar", placeholder: "17:00" },
    { key: "notes", label: "Catatan", type: "textarea" as const, hideInTable: true },
  ];

  return (
    <CrudTable
      title="Absensi"
      description="Catatan kehadiran karyawan harian"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["employeeName", "status"]}
      filterField="status"
      filterOptions={[{ value: "hadir", label: "Hadir" }, { value: "sakit", label: "Sakit" }, { value: "izin", label: "Izin" }, { value: "cuti", label: "Cuti" }, { value: "alpha", label: "Alpha" }]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.attendance.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.attendance.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.attendance.list.invalidate(); }}
    />
  );
}
