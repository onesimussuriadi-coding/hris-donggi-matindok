import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Building2, Plus, Search, Pencil, Trash2, Layers } from "lucide-react";
import { toast } from "sonner";
import CrudTable from "@/components/CrudTable";

export default function Company() {
  const [tab, setTab] = useState<"company" | "division">("company");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Perusahaan & Divisi</h1>
        <p className="text-sm text-muted-foreground mt-1">Kelola data perusahaan dan divisi</p>
      </div>

      <div className="flex gap-2 border-b">
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === "company" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setTab("company")}
        >
          Perusahaan
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === "division" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setTab("division")}
        >
          Divisi
        </button>
      </div>

      {tab === "company" ? <CompanyTab /> : <DivisionTab />}
    </div>
  );
}

function CompanyTab() {
  const { data, isLoading } = trpc.company.list.useQuery();
  const createMut = trpc.company.create.useMutation();
  const updateMut = trpc.company.update.useMutation();
  const deleteMut = trpc.company.delete.useMutation();
  const utils = trpc.useUtils();

  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", address: "", phone: "", email: "", npwp: "" });

  const filtered = useMemo(() => {
    if (!data) return [];
    const q = search.toLowerCase();
    return data.filter(c => c.name?.toLowerCase().includes(q) || c.email?.toLowerCase().includes(q));
  }, [data, search]);

  const openCreate = () => {
    setEditingId(null);
    setForm({ name: "", address: "", phone: "", email: "", npwp: "" });
    setDialogOpen(true);
  };

  const openEdit = (c: any) => {
    setEditingId(c.id);
    setForm({ name: c.name || "", address: c.address || "", phone: c.phone || "", email: c.email || "", npwp: c.npwp || "" });
    setDialogOpen(true);
  };

  const submit = () => {
    if (!form.name) { toast.error("Nama perusahaan wajib diisi"); return; }
    if (editingId !== null) {
      (updateMut.mutate as any)({ id: editingId, ...form });
      toast.success("Perusahaan diperbarui");
    } else {
      (createMut.mutate as any)(form);
      toast.success("Perusahaan ditambahkan");
    }
    utils.company.list.invalidate();
    setDialogOpen(false);
  };

  const del = (id: number) => {
    (deleteMut.mutate as any)({ id });
    utils.company.list.invalidate();
    toast.success("Perusahaan dihapus");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Cari perusahaan..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Button onClick={openCreate} className="gap-2"><Plus className="h-4 w-4" />Tambah Perusahaan</Button>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Memuat data...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><p>Belum ada data perusahaan.</p></div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map(c => (
            <Card key={c.id} className="shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Building2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-base">{c.name}</CardTitle>
                    <p className="text-xs text-muted-foreground">{c.email || "-"}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => del(c.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 text-sm">
                  <p className="text-muted-foreground"><span className="font-medium text-foreground">Alamat:</span> {c.address || "-"}</p>
                  <p className="text-muted-foreground"><span className="font-medium text-foreground">Telepon:</span> {c.phone || "-"}</p>
                  <p className="text-muted-foreground"><span className="font-medium text-foreground">NPWP:</span> {c.npwp || "-"}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingId !== null ? "Edit Perusahaan" : "Tambah Perusahaan"}</DialogTitle></DialogHeader>
          <div className="grid gap-4 py-4">
            <div><label className="text-sm font-medium mb-1.5 block">Nama Perusahaan *</label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
            <div><label className="text-sm font-medium mb-1.5 block">Alamat</label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="text-sm font-medium mb-1.5 block">Telepon</label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
              <div><label className="text-sm font-medium mb-1.5 block">Email</label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            </div>
            <div><label className="text-sm font-medium mb-1.5 block">NPWP</label><Input value={form.npwp} onChange={e => setForm({ ...form, npwp: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Batal</Button>
            <Button onClick={submit}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DivisionTab() {
  const { data: companies } = trpc.company.list.useQuery();
  const { data, isLoading } = trpc.division.list.useQuery();
  const createMut = trpc.division.create.useMutation();
  const updateMut = trpc.division.update.useMutation();
  const deleteMut = trpc.division.delete.useMutation();
  const utils = trpc.useUtils();

  const companyMap = useMemo(() => {
    const m: Record<number, string> = {};
    (companies || []).forEach(c => { m[c.id] = c.name; });
    return m;
  }, [companies]);

  const companyOptions = (companies || []).map(c => ({ value: String(c.id), label: c.name }));

  const fields = [
    { key: "name", label: "Nama Divisi", required: true },
    { key: "code", label: "Kode" },
    { key: "companyId", label: "Perusahaan", type: "select" as const, options: companyOptions, required: true, hideInTable: false },
    { key: "head", label: "Kepala Divisi" },
    { key: "description", label: "Deskripsi", type: "textarea" as const, hideInTable: true },
  ];

  const processedData = (data || []).map((d: any) => ({
    ...d,
    companyName: companyMap[d.companyId] || "-",
  }));

  const tableFields = [
    { key: "name", label: "Nama Divisi" },
    { key: "code", label: "Kode" },
    { key: "companyName", label: "Perusahaan", hideInForm: true },
    { key: "head", label: "Kepala Divisi" },
  ];

  return (
    <CrudTable
      title="Divisi"
      description="Kelola divisi perusahaan"
      fields={[...fields, ...tableFields.filter(tf => !fields.some(f => f.key === tf.key))].map(f => ({
        ...f,
        hideInTable: f.key === "companyId" || f.key === "description" || f.key === "companyName",
        hideInForm: f.key === "companyName",
      }))}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["name", "code", "head"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.division.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.division.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.division.list.invalidate(); }}
    />
  );
}
