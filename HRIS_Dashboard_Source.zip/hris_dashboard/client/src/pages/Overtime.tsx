import { useMemo } from "react";
import { trpc } from "@/lib/trpc";
import CrudTable from "@/components/CrudTable";

export default function Overtime() {
  const { data, isLoading } = trpc.overtime.list.useQuery();
  const { data: employees } = trpc.employee.list.useQuery();
  const createMut = trpc.overtime.create.useMutation();
  const updateMut = trpc.overtime.update.useMutation();
  const deleteMut = trpc.overtime.delete.useMutation();
  const utils = trpc.useUtils();

  const empMap = useMemo(() => { const m: Record<number, string> = {}; (employees || []).forEach(e => { m[e.id] = `${e.nik} - ${e.name}`; }); return m; }, [employees]);
  const empOptions = (employees || []).map(e => ({ value: String(e.id), label: `${e.nik} - ${e.name}` }));

  const processedData = (data || []).map((o: any) => ({
    ...o,
    employeeName: empMap[o.employeeId] || "-",
    dateFmt: o.date ? new Date(o.date).toLocaleDateString('id-ID') : "-",
    amountFmt: o.amount ? Number(o.amount).toLocaleString('id-ID') : "-",
    dayTypeLabel: o.dayType === "kerja" ? "Hari Kerja" : o.dayType === "libur" ? "Hari Libur" : o.dayType === "besar" ? "Hari Besar" : "-",
  }));

  const fields = [
    { key: "employeeId", label: "Karyawan", type: "select" as const, options: empOptions, required: true, hideInTable: true },
    { key: "employeeName", label: "Karyawan", hideInForm: true },
    { key: "date", label: "Tanggal", type: "date" as const, required: true, hideInTable: true },
    { key: "dateFmt", label: "Tanggal", hideInForm: true },
    { key: "startTime", label: "Jam Mulai", required: true, placeholder: "17:00" },
    { key: "endTime", label: "Jam Selesai", required: true, placeholder: "20:00" },
    { key: "dayType", label: "Jenis Hari", type: "select" as const, options: [{ value: "kerja", label: "Hari Kerja" }, { value: "libur", label: "Hari Libur" }, { value: "besar", label: "Hari Besar" }], required: true, hideInTable: true },
    { key: "dayTypeLabel", label: "Jenis Hari", hideInForm: true },
    { key: "hours", label: "Jam Lembur", type: "number" as const, hideInForm: true },
    { key: "amount", label: "Jumlah Upah", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "amountFmt", label: "Upah Lembur", hideInForm: true },
    { key: "notes", label: "Catatan", type: "textarea" as const, hideInTable: true },
  ];

  return (
    <CrudTable
      title="Lembur (Overtime)"
      description="Catatan lembur karyawan — jam dihitung otomatis dari jam mulai dan selesai"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["employeeName", "dayTypeLabel"]}
      filterField="dayTypeLabel"
      filterOptions={[{ value: "Hari Kerja", label: "Hari Kerja" }, { value: "Hari Libur", label: "Hari Libur" }, { value: "Hari Besar", label: "Hari Besar" }]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.overtime.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.overtime.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.overtime.list.invalidate(); }}
    />
  );
}
