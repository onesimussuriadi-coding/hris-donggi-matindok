import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import CrudTable from "@/components/CrudTable";

export default function Allowances() {
  const [tab, setTab] = useState<"allowance" | "deduction" | "empAllowance" | "empDeduction">("allowance");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Tunjangan & Potongan</h1>
        <p className="text-sm text-muted-foreground mt-1">Kelola master tunjangan, potongan, dan penugasannya ke karyawan</p>
      </div>

      <div className="flex gap-2 border-b overflow-x-auto">
        {[
          { key: "allowance", label: "Master Tunjangan" },
          { key: "deduction", label: "Master Potongan" },
          { key: "empAllowance", label: "Tunjangan Karyawan" },
          { key: "empDeduction", label: "Potongan Karyawan" },
        ].map(t => (
          <button
            key={t.key}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${tab === t.key ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
            onClick={() => setTab(t.key as any)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "allowance" && <AllowanceTab />}
      {tab === "deduction" && <DeductionTab />}
      {tab === "empAllowance" && <EmpAllowanceTab />}
      {tab === "empDeduction" && <EmpDeductionTab />}
    </div>
  );
}

function AllowanceTab() {
  const { data, isLoading } = trpc.allowance.list.useQuery();
  const createMut = trpc.allowance.create.useMutation();
  const updateMut = trpc.allowance.update.useMutation();
  const deleteMut = trpc.allowance.delete.useMutation();
  const utils = trpc.useUtils();

  const processedData = (data || []).map((a: any) => ({
    ...a,
    amountFmt: a.amount ? Number(a.amount).toLocaleString('id-ID') : "-",
    taxableLabel: a.isTaxable === "yes" ? "Ya" : "Tidak",
  }));

  const fields = [
    { key: "name", label: "Nama Tunjangan", required: true },
    { key: "type", label: "Jenis", type: "select" as const, options: [{ value: "fixed", label: "Tetap" }, { value: "variable", label: "Variabel" }] },
    { key: "amount", label: "Jumlah", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "amountFmt", label: "Jumlah", hideInForm: true },
    { key: "isTaxable", label: "Dikenakan Pajak", type: "select" as const, options: [{ value: "yes", label: "Ya" }, { value: "no", label: "Tidak" }], hideInTable: true },
    { key: "taxableLabel", label: "Pajak", hideInForm: true },
    { key: "description", label: "Deskripsi", type: "textarea" as const, hideInTable: true },
  ];

  return (
    <CrudTable
      title="Master Tunjangan"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["name"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.allowance.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.allowance.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.allowance.list.invalidate(); }}
    />
  );
}

function DeductionTab() {
  const { data, isLoading } = trpc.deduction.list.useQuery();
  const createMut = trpc.deduction.create.useMutation();
  const updateMut = trpc.deduction.update.useMutation();
  const deleteMut = trpc.deduction.delete.useMutation();
  const utils = trpc.useUtils();

  const processedData = (data || []).map((d: any) => ({
    ...d,
    amountFmt: d.amount ? Number(d.amount).toLocaleString('id-ID') : "-",
  }));

  const fields = [
    { key: "name", label: "Nama Potongan", required: true },
    { key: "type", label: "Jenis", type: "select" as const, options: [{ value: "fixed", label: "Tetap" }, { value: "variable", label: "Variabel" }] },
    { key: "amount", label: "Jumlah", type: "number" as const, hideInTable: true, placeholder: "0" },
    { key: "amountFmt", label: "Jumlah", hideInForm: true },
    { key: "description", label: "Deskripsi", type: "textarea" as const, hideInTable: true },
  ];

  return (
    <CrudTable
      title="Master Potongan"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["name"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.deduction.list.invalidate(); }}
      onUpdate={(id, d) => { (updateMut.mutate as any)({ id, ...d }); utils.deduction.list.invalidate(); }}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.deduction.list.invalidate(); }}
    />
  );
}

function EmpAllowanceTab() {
  const { data, isLoading } = trpc.employeeAllowance.list.useQuery();
  const { data: employees } = trpc.employee.list.useQuery();
  const { data: allowances } = trpc.allowance.list.useQuery();
  const createMut = trpc.employeeAllowance.create.useMutation();
  const deleteMut = trpc.employeeAllowance.delete.useMutation();
  const utils = trpc.useUtils();

  const empMap = useMemo(() => { const m: Record<number, string> = {}; (employees || []).forEach(e => { m[e.id] = `${e.nik} - ${e.name}`; }); return m; }, [employees]);
  const allowMap = useMemo(() => { const m: Record<number, string> = {}; (allowances || []).forEach(a => { m[a.id] = a.name; }); return m; }, [allowances]);
  const empOptions = (employees || []).map(e => ({ value: String(e.id), label: `${e.nik} - ${e.name}` }));
  const allowOptions = (allowances || []).map(a => ({ value: String(a.id), label: a.name }));

  const processedData = (data || []).map((ea: any) => ({
    ...ea,
    employeeName: empMap[ea.employeeId] || "-",
    allowanceName: allowMap[ea.allowanceId] || "-",
    amountFmt: ea.amount ? Number(ea.amount).toLocaleString('id-ID') : "-",
  }));

  const fields = [
    { key: "employeeId", label: "Karyawan", type: "select" as const, options: empOptions, required: true, hideInTable: true },
    { key: "employeeName", label: "Karyawan", hideInForm: true },
    { key: "allowanceId", label: "Tunjangan", type: "select" as const, options: allowOptions, required: true, hideInTable: true },
    { key: "allowanceName", label: "Tunjangan", hideInForm: true },
    { key: "amount", label: "Jumlah", type: "number" as const, required: true, placeholder: "0" },
    { key: "amountFmt", label: "Jumlah", hideInForm: true },
  ];

  return (
    <CrudTable
      title="Tunjangan Karyawan"
      description="Penugasan tunjangan ke karyawan"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["employeeName", "allowanceName"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.employeeAllowance.list.invalidate(); }}
      onUpdate={() => {}}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.employeeAllowance.list.invalidate(); }}
    />
  );
}

function EmpDeductionTab() {
  const { data, isLoading } = trpc.employeeDeduction.list.useQuery();
  const { data: employees } = trpc.employee.list.useQuery();
  const { data: deductions } = trpc.deduction.list.useQuery();
  const createMut = trpc.employeeDeduction.create.useMutation();
  const deleteMut = trpc.employeeDeduction.delete.useMutation();
  const utils = trpc.useUtils();

  const empMap = useMemo(() => { const m: Record<number, string> = {}; (employees || []).forEach(e => { m[e.id] = `${e.nik} - ${e.name}`; }); return m; }, [employees]);
  const dedMap = useMemo(() => { const m: Record<number, string> = {}; (deductions || []).forEach(d => { m[d.id] = d.name; }); return m; }, [deductions]);
  const empOptions = (employees || []).map(e => ({ value: String(e.id), label: `${e.nik} - ${e.name}` }));
  const dedOptions = (deductions || []).map(d => ({ value: String(d.id), label: d.name }));

  const processedData = (data || []).map((ed: any) => ({
    ...ed,
    employeeName: empMap[ed.employeeId] || "-",
    deductionName: dedMap[ed.deductionId] || "-",
    amountFmt: ed.amount ? Number(ed.amount).toLocaleString('id-ID') : "-",
  }));

  const fields = [
    { key: "employeeId", label: "Karyawan", type: "select" as const, options: empOptions, required: true, hideInTable: true },
    { key: "employeeName", label: "Karyawan", hideInForm: true },
    { key: "deductionId", label: "Potongan", type: "select" as const, options: dedOptions, required: true, hideInTable: true },
    { key: "deductionName", label: "Potongan", hideInForm: true },
    { key: "amount", label: "Jumlah", type: "number" as const, required: true, placeholder: "0" },
    { key: "amountFmt", label: "Jumlah", hideInForm: true },
  ];

  return (
    <CrudTable
      title="Potongan Karyawan"
      description="Penugasan potongan ke karyawan"
      fields={fields}
      data={processedData}
      isLoading={isLoading}
      searchKeys={["employeeName", "deductionName"]}
      onCreate={(d) => { (createMut.mutate as any)(d); utils.employeeDeduction.list.invalidate(); }}
      onUpdate={() => {}}
      onDelete={(id) => { (deleteMut.mutate as any)({ id }); utils.employeeDeduction.list.invalidate(); }}
    />
  );
}
