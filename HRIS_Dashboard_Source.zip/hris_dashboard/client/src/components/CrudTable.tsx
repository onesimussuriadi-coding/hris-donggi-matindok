import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Pencil, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";

export type FieldDef = {
  key: string;
  label: string;
  type?: "text" | "number" | "date" | "select" | "textarea";
  options?: { value: string; label: string }[];
  required?: boolean;
  placeholder?: string;
  hideInTable?: boolean;
  hideInForm?: boolean;
  width?: string;
};

export type CrudTableProps = {
  title: string;
  description?: string;
  fields: FieldDef[];
  data: any[];
  isLoading?: boolean;
  onCreate: (data: any) => void;
  onUpdate: (id: number, data: any) => void;
  onDelete: (id: number) => void;
  searchKeys?: string[];
  filterField?: string;
  filterOptions?: { value: string; label: string }[];
  extraActions?: React.ReactNode;
};

export default function CrudTable({
  title, description, fields, data, isLoading,
  onCreate, onUpdate, onDelete,
  searchKeys = [], filterField, filterOptions, extraActions,
}: CrudTableProps) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});

  const filteredData = useMemo(() => {
    let result = data;
    if (search && searchKeys.length > 0) {
      const q = search.toLowerCase();
      result = result.filter(row =>
        searchKeys.some(key => {
          const val = row[key];
          return val != null && String(val).toLowerCase().includes(q);
        })
      );
    }
    if (filter !== "all" && filterField) {
      result = result.filter(row => String(row[filterField]) === filter);
    }
    return result;
  }, [data, search, searchKeys, filter, filterField]);

  const openCreate = () => {
    setEditingId(null);
    const empty: Record<string, any> = {};
    fields.forEach(f => {
      if (f.type === "select" && f.options?.length) empty[f.key] = f.options[0].value;
      else if (f.type === "number") empty[f.key] = "";
      else empty[f.key] = "";
    });
    setFormData(empty);
    setDialogOpen(true);
  };

  const openEdit = (row: any) => {
    setEditingId(row.id);
    const editData: Record<string, any> = {};
    fields.forEach(f => {
      let val = row[f.key];
      if (f.type === "date" && val) {
        val = new Date(val).toISOString().split('T')[0];
      }
      editData[f.key] = val ?? "";
    });
    setFormData(editData);
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    const required = fields.filter(f => f.required);
    for (const f of required) {
      if (!formData[f.key] || formData[f.key] === "") {
        toast.error(`${f.label} wajib diisi`);
        return;
      }
    }
    const submitData = { ...formData };
    fields.forEach(f => {
      if (f.type === "date" && submitData[f.key]) {
        submitData[f.key] = new Date(submitData[f.key]).getTime();
      }
      if (f.type === "number" && submitData[f.key] !== "") {
        submitData[f.key] = String(submitData[f.key]);
      }
    });
    if (editingId !== null) {
      onUpdate(editingId, submitData);
      toast.success("Data berhasil diperbarui");
    } else {
      onCreate(submitData);
      toast.success("Data berhasil ditambahkan");
    }
    setDialogOpen(false);
  };

  const handleDelete = (id: number) => {
    onDelete(id);
    toast.success("Data berhasil dihapus");
  };

  const tableFields = fields.filter(f => !f.hideInTable);
  const formFields = fields.filter(f => !f.hideInForm);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
        </div>
        <div className="flex items-center gap-2">
          {extraActions}
          <Button onClick={openCreate} className="gap-2">
            <Plus className="h-4 w-4" />
            Tambah Data
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            {filterField && filterOptions && (
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua</SelectItem>
                  {filterOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredData.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">Belum ada data. Klik "Tambah Data" untuk memulai.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {tableFields.map(f => (
                      <TableHead key={f.key} className={f.width}>{f.label}</TableHead>
                    ))}
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredData.map((row, idx) => (
                    <TableRow key={row.id ?? idx}>
                      {tableFields.map(f => {
                        let val = row[f.key];
                        if (f.type === "date" && val) {
                          val = new Date(val).toLocaleDateString('id-ID');
                        }
                        if (f.type === "select" && f.options) {
                          const opt = f.options.find(o => o.value === String(val));
                          val = opt?.label || val;
                        }
                        if (f.type === "number" && val != null) {
                          val = Number(val).toLocaleString('id-ID');
                        }
                        return <TableCell key={f.key}>{val ?? "-"}</TableCell>;
                      })}
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" onClick={() => openEdit(row)} className="h-8 w-8">
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(row.id)} className="h-8 w-8 text-destructive hover:text-destructive">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId !== null ? "Edit Data" : "Tambah Data"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            {formFields.map(f => (
              <div key={f.key} className={f.type === "textarea" ? "col-span-2" : ""}>
                <label className="text-sm font-medium mb-1.5 block">
                  {f.label}{f.required && <span className="text-destructive ml-1">*</span>}
                </label>
                {f.type === "select" ? (
                  <Select
                    value={String(formData[f.key] ?? "")}
                    onValueChange={v => setFormData(prev => ({ ...prev, [f.key]: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={f.placeholder || "Pilih..."} />
                    </SelectTrigger>
                    <SelectContent>
                      {f.options?.map(opt => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : f.type === "textarea" ? (
                  <textarea
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    rows={3}
                    value={formData[f.key] ?? ""}
                    onChange={e => setFormData(prev => ({ ...prev, [f.key]: e.target.value }))}
                    placeholder={f.placeholder}
                  />
                ) : (
                  <Input
                    type={f.type === "date" ? "date" : f.type === "number" ? "number" : "text"}
                    value={formData[f.key] ?? ""}
                    onChange={e => setFormData(prev => ({ ...prev, [f.key]: e.target.value }))}
                    placeholder={f.placeholder}
                  />
                )}
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Batal</Button>
            <Button onClick={handleSubmit}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
