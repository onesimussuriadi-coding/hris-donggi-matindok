# Project TODO — HRIS Dashboard

- [x] Project setup & database schema (16 tables)
- [x] Layout, sidebar, and main Dashboard page
- [x] Core data modules: Karyawan, Divisi & Jabatan, Shift, Tunjangan & Potongan
- [x] Attendance & Overtime modules
- [x] Payroll engine with BPJS, PPh21, and take home pay calculation
- [x] Payslip PDF generation & Reports/Analytics page
- [x] Settings page for BPJS/PPh21/overtime configuration
- [x] TypeScript compilation check
- [x] Vitest tests (7 tests passing)
- [ ] Final checkpoint & delivery
