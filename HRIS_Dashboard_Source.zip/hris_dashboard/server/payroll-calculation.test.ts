import { describe, expect, it } from "vitest";
import { calculateBPJS, calculateOvertimePay, calculatePPh21 } from "./db";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createUnauthenticatedContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("perhitungan payroll HRIS", () => {
  it("menerapkan batas upah BPJS Kesehatan dan JP serta persentase iuran pekerja", () => {
    expect(calculateBPJS(15_000_000)).toEqual({
      bpjsKes: 120_000,
      bpjsJHT: 300_000,
      bpjsJP: 105_474,
      bpjsTkTotal: 405_474,
    });
  });

  it("menghitung lembur hari kerja dengan tarif 1,5x pada jam pertama dan 2x setelahnya", () => {
    expect(calculateOvertimePay(17_300_000, 2, "kerja")).toBe(350_000);
  });

  it("menghitung lembur hari libur untuk pola kerja lima hari", () => {
    expect(calculateOvertimePay(17_300_000, 9, "libur", 5)).toBe(1_900_000);
  });

  it("menghasilkan PPh 21 bulanan nol ketika penghasilan neto belum melewati PTKP", () => {
    expect(calculatePPh21(4_500_000, "TK0")).toBe(0);
  });

  it("menghitung PPh 21 bulanan berdasarkan lapisan tarif progresif", () => {
    expect(calculatePPh21(10_000_000, "TK0")).toBe(250_000);
  });
});

describe("keamanan router HRIS", () => {
  it("menolak akses data karyawan jika pengguna belum terautentikasi", async () => {
    const caller = appRouter.createCaller(createUnauthenticatedContext());

    await expect(caller.employee.list()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });
});
