import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Company ──────────────────────────────────────────────────────────────
  company: router({
    list: protectedProcedure.query(() => db.getCompanies()),
    create: protectedProcedure.mutation(({ input }) => db.createCompany(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateCompany(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteCompany(input.id)),
  }),

  // ─── Division ─────────────────────────────────────────────────────────────
  division: router({
    list: protectedProcedure.query(() => db.getDivisions()),
    create: protectedProcedure.mutation(({ input }) => db.createDivision(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateDivision(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteDivision(input.id)),
  }),

  // ─── Position ─────────────────────────────────────────────────────────────
  position: router({
    list: protectedProcedure.query(() => db.getPositions()),
    create: protectedProcedure.mutation(({ input }) => db.createPosition(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updatePosition(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deletePosition(input.id)),
  }),

  // ─── Employee ─────────────────────────────────────────────────────────────
  employee: router({
    list: protectedProcedure.query(() => db.getEmployees()),
    create: protectedProcedure.mutation(({ input }) => db.createEmployee(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateEmployee(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteEmployee(input.id)),
  }),

  // ─── Shift ────────────────────────────────────────────────────────────────
  shift: router({
    list: protectedProcedure.query(() => db.getShifts()),
    create: protectedProcedure.mutation(({ input }) => db.createShift(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateShift(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteShift(input.id)),
  }),

  // ─── Employee Shift ───────────────────────────────────────────────────────
  employeeShift: router({
    list: protectedProcedure.query(() => db.getEmployeeShifts()),
    create: protectedProcedure.mutation(({ input }) => db.createEmployeeShift(input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteEmployeeShift(input.id)),
  }),

  // ─── Attendance ───────────────────────────────────────────────────────────
  attendance: router({
    list: protectedProcedure.query(() => db.getAttendance()),
    create: protectedProcedure.mutation(({ input }) => db.createAttendance(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateAttendance(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteAttendance(input.id)),
  }),

  // ─── Overtime ─────────────────────────────────────────────────────────────
  overtime: router({
    list: protectedProcedure.query(() => db.getOvertime()),
    create: protectedProcedure.mutation(({ input }) => db.createOvertime(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateOvertime(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteOvertime(input.id)),
  }),

  // ─── Allowance ────────────────────────────────────────────────────────────
  allowance: router({
    list: protectedProcedure.query(() => db.getAllowances()),
    create: protectedProcedure.mutation(({ input }) => db.createAllowance(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateAllowance(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteAllowance(input.id)),
  }),

  employeeAllowance: router({
    list: protectedProcedure.query(() => db.getEmployeeAllowances()),
    create: protectedProcedure.mutation(({ input }) => db.createEmployeeAllowance(input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteEmployeeAllowance(input.id)),
  }),

  // ─── Deduction ────────────────────────────────────────────────────────────
  deduction: router({
    list: protectedProcedure.query(() => db.getDeductions()),
    create: protectedProcedure.mutation(({ input }) => db.createDeduction(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updateDeduction(input.id, input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteDeduction(input.id)),
  }),

  employeeDeduction: router({
    list: protectedProcedure.query(() => db.getEmployeeDeductions()),
    create: protectedProcedure.mutation(({ input }) => db.createEmployeeDeduction(input)),
    delete: protectedProcedure.mutation(({ input }: any) => db.deleteEmployeeDeduction(input.id)),
  }),

  // ─── Payroll ──────────────────────────────────────────────────────────────
  payrollPeriod: router({
    list: protectedProcedure.query(() => db.getPayrollPeriods()),
    create: protectedProcedure.mutation(({ input }) => db.createPayrollPeriod(input)),
    update: protectedProcedure.mutation(({ input }: any) => db.updatePayrollPeriod(input.id, input)),
  }),

  payrollItem: router({
    list: protectedProcedure.input(z.object({ periodId: z.number().optional() }).optional()).query(({ input }) => db.getPayrollItems(input?.periodId)),
  }),

  payroll: router({
    process: protectedProcedure.mutation(({ input }: any) => db.processPayroll(input.periodId)),
    stats: protectedProcedure.query(() => db.getDashboardStats()),
  }),

  // ─── Settings ─────────────────────────────────────────────────────────────
  settings: router({
    list: protectedProcedure.query(() => db.getSettings()),
    upsert: protectedProcedure.mutation(({ input }: any) => db.upsertSetting(input.key, input.value, input.description)),
  }),
});

export type AppRouter = typeof appRouter;
