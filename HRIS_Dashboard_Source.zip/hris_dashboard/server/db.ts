import { eq, and, gte, lte, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  companies, divisions, positions, employees, shifts, employeeShifts,
  attendance, overtime, allowances, employeeAllowances,
  deductions, employeeDeductions, payrollPeriods, payrollItems, settings,
  InsertUser, users,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── User (auth) ────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      const value = user[field];
      if (value !== undefined) { const n = value ?? null; values[field] = n; updateSet[field] = n; }
    });
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Company ────────────────────────────────────────────────────────────────

export async function getCompanies() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(companies).orderBy(desc(companies.createdAt));
}
export async function createCompany(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(companies).values(data);
  const result = await db.select().from(companies).orderBy(desc(companies.id)).limit(1);
  return result[0];
}
export async function updateCompany(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  await db.update(companies).set(data).where(eq(companies.id, id));
  const result = await db.select().from(companies).where(eq(companies.id, id)).limit(1);
  return result[0];
}
export async function deleteCompany(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(companies).where(eq(companies.id, id));
  return { success: true };
}

// ─── Division ───────────────────────────────────────────────────────────────

export async function getDivisions() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(divisions).orderBy(desc(divisions.createdAt));
}
export async function createDivision(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(divisions).values(data);
  const result = await db.select().from(divisions).orderBy(desc(divisions.id)).limit(1);
  return result[0];
}
export async function updateDivision(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  await db.update(divisions).set(data).where(eq(divisions.id, id));
  const result = await db.select().from(divisions).where(eq(divisions.id, id)).limit(1);
  return result[0];
}
export async function deleteDivision(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(divisions).where(eq(divisions.id, id));
  return { success: true };
}

// ─── Position ───────────────────────────────────────────────────────────────

export async function getPositions() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(positions).orderBy(desc(positions.createdAt));
}
export async function createPosition(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(positions).values(data);
  const result = await db.select().from(positions).orderBy(desc(positions.id)).limit(1);
  return result[0];
}
export async function updatePosition(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  await db.update(positions).set(data).where(eq(positions.id, id));
  const result = await db.select().from(positions).where(eq(positions.id, id)).limit(1);
  return result[0];
}
export async function deletePosition(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(positions).where(eq(positions.id, id));
  return { success: true };
}

// ─── Employee ───────────────────────────────────────────────────────────────

export async function getEmployees() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(employees).orderBy(desc(employees.createdAt));
}
export async function getEmployeeById(id: number) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(employees).where(eq(employees.id, id)).limit(1);
  return result[0];
}
export async function createEmployee(data: any) {
  const db = await getDb(); if (!db) return;
  if (data.birthDate) data.birthDate = new Date(data.birthDate);
  if (data.hireDate) data.hireDate = new Date(data.hireDate);
  if (data.resignDate) data.resignDate = new Date(data.resignDate);
  await db.insert(employees).values(data);
  const result = await db.select().from(employees).orderBy(desc(employees.id)).limit(1);
  return result[0];
}
export async function updateEmployee(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  if (data.birthDate) data.birthDate = new Date(data.birthDate);
  if (data.hireDate) data.hireDate = new Date(data.hireDate);
  if (data.resignDate) data.resignDate = new Date(data.resignDate);
  await db.update(employees).set(data).where(eq(employees.id, id));
  const result = await db.select().from(employees).where(eq(employees.id, id)).limit(1);
  return result[0];
}
export async function deleteEmployee(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(employees).where(eq(employees.id, id));
  return { success: true };
}

// ─── Shift ──────────────────────────────────────────────────────────────────

export async function getShifts() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(shifts).orderBy(desc(shifts.createdAt));
}
export async function createShift(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(shifts).values(data);
  const result = await db.select().from(shifts).orderBy(desc(shifts.id)).limit(1);
  return result[0];
}
export async function updateShift(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  await db.update(shifts).set(data).where(eq(shifts.id, id));
  const result = await db.select().from(shifts).where(eq(shifts.id, id)).limit(1);
  return result[0];
}
export async function deleteShift(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(shifts).where(eq(shifts.id, id));
  return { success: true };
}

// ─── Employee Shifts ────────────────────────────────────────────────────────

export async function getEmployeeShifts() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(employeeShifts).orderBy(desc(employeeShifts.date));
}
export async function createEmployeeShift(data: any) {
  const db = await getDb(); if (!db) return;
  if (data.date) data.date = new Date(data.date);
  await db.insert(employeeShifts).values(data);
  const result = await db.select().from(employeeShifts).orderBy(desc(employeeShifts.id)).limit(1);
  return result[0];
}
export async function deleteEmployeeShift(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(employeeShifts).where(eq(employeeShifts.id, id));
  return { success: true };
}

// ─── Attendance ─────────────────────────────────────────────────────────────

export async function getAttendance() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(attendance).orderBy(desc(attendance.date));
}
export async function createAttendance(data: any) {
  const db = await getDb(); if (!db) return;
  if (data.date) data.date = new Date(data.date);
  await db.insert(attendance).values(data);
  const result = await db.select().from(attendance).orderBy(desc(attendance.id)).limit(1);
  return result[0];
}
export async function updateAttendance(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  if (data.date) data.date = new Date(data.date);
  await db.update(attendance).set(data).where(eq(attendance.id, id));
  const result = await db.select().from(attendance).where(eq(attendance.id, id)).limit(1);
  return result[0];
}
export async function deleteAttendance(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(attendance).where(eq(attendance.id, id));
  return { success: true };
}

// ─── Overtime ───────────────────────────────────────────────────────────────

export async function getOvertime() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(overtime).orderBy(desc(overtime.date));
}
export async function createOvertime(data: any) {
  const db = await getDb(); if (!db) return;
  if (data.date) data.date = new Date(data.date);
  if (data.startTime && data.endTime) {
    data.hours = calculateOvertimeHours(data.startTime, data.endTime);
  }
  await db.insert(overtime).values(data);
  const result = await db.select().from(overtime).orderBy(desc(overtime.id)).limit(1);
  return result[0];
}
export async function updateOvertime(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  if (data.date) data.date = new Date(data.date);
  if (data.startTime && data.endTime) {
    data.hours = calculateOvertimeHours(data.startTime, data.endTime);
  }
  await db.update(overtime).set(data).where(eq(overtime.id, id));
  const result = await db.select().from(overtime).where(eq(overtime.id, id)).limit(1);
  return result[0];
}
export async function deleteOvertime(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(overtime).where(eq(overtime.id, id));
  return { success: true };
}

// ─── Allowances ─────────────────────────────────────────────────────────────

export async function getAllowances() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(allowances).orderBy(desc(allowances.createdAt));
}
export async function createAllowance(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(allowances).values(data);
  const result = await db.select().from(allowances).orderBy(desc(allowances.id)).limit(1);
  return result[0];
}
export async function updateAllowance(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  await db.update(allowances).set(data).where(eq(allowances.id, id));
  const result = await db.select().from(allowances).where(eq(allowances.id, id)).limit(1);
  return result[0];
}
export async function deleteAllowance(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(allowances).where(eq(allowances.id, id));
  return { success: true };
}

export async function getEmployeeAllowances() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(employeeAllowances);
}
export async function createEmployeeAllowance(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(employeeAllowances).values(data);
  const result = await db.select().from(employeeAllowances).orderBy(desc(employeeAllowances.id)).limit(1);
  return result[0];
}
export async function deleteEmployeeAllowance(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(employeeAllowances).where(eq(employeeAllowances.id, id));
  return { success: true };
}

// ─── Deductions ─────────────────────────────────────────────────────────────

export async function getDeductions() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(deductions).orderBy(desc(deductions.createdAt));
}
export async function createDeduction(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(deductions).values(data);
  const result = await db.select().from(deductions).orderBy(desc(deductions.id)).limit(1);
  return result[0];
}
export async function updateDeduction(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  await db.update(deductions).set(data).where(eq(deductions.id, id));
  const result = await db.select().from(deductions).where(eq(deductions.id, id)).limit(1);
  return result[0];
}
export async function deleteDeduction(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(deductions).where(eq(deductions.id, id));
  return { success: true };
}

export async function getEmployeeDeductions() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(employeeDeductions);
}
export async function createEmployeeDeduction(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(employeeDeductions).values(data);
  const result = await db.select().from(employeeDeductions).orderBy(desc(employeeDeductions.id)).limit(1);
  return result[0];
}
export async function deleteEmployeeDeduction(id: number) {
  const db = await getDb(); if (!db) return { success: false };
  await db.delete(employeeDeductions).where(eq(employeeDeductions.id, id));
  return { success: true };
}

// ─── Payroll ────────────────────────────────────────────────────────────────

export async function getPayrollPeriods() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(payrollPeriods).orderBy(desc(payrollPeriods.period));
}
export async function getPayrollPeriodById(id: number) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(payrollPeriods).where(eq(payrollPeriods.id, id)).limit(1);
  return result[0];
}
export async function createPayrollPeriod(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(payrollPeriods).values(data);
  const result = await db.select().from(payrollPeriods).orderBy(desc(payrollPeriods.id)).limit(1);
  return result[0];
}
export async function updatePayrollPeriod(id: number, data: any) {
  const db = await getDb(); if (!db) return;
  if (data.processedAt) data.processedAt = new Date(data.processedAt);
  if (data.approvedAt) data.approvedAt = new Date(data.approvedAt);
  if (data.paidAt) data.paidAt = new Date(data.paidAt);
  await db.update(payrollPeriods).set(data).where(eq(payrollPeriods.id, id));
  const result = await db.select().from(payrollPeriods).where(eq(payrollPeriods.id, id)).limit(1);
  return result[0];
}

export async function getPayrollItems(periodId?: number) {
  const db = await getDb(); if (!db) return [];
  if (periodId) {
    return db.select().from(payrollItems).where(eq(payrollItems.payrollPeriodId, periodId));
  }
  return db.select().from(payrollItems).orderBy(desc(payrollItems.createdAt));
}
export async function createPayrollItem(data: any) {
  const db = await getDb(); if (!db) return;
  await db.insert(payrollItems).values(data);
  const result = await db.select().from(payrollItems).orderBy(desc(payrollItems.id)).limit(1);
  return result[0];
}
export async function deletePayrollItemsByPeriod(periodId: number) {
  const db = await getDb(); if (!db) return;
  await db.delete(payrollItems).where(eq(payrollItems.payrollPeriodId, periodId));
}

// ─── Settings ───────────────────────────────────────────────────────────────

export async function getSettings() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(settings);
}
export async function getSetting(key: string) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return result[0]?.value;
}
export async function upsertSetting(key: string, value: string, description?: string) {
  const db = await getDb(); if (!db) return;
  await db.insert(settings).values({ key, value, description }).onDuplicateKeyUpdate({ set: { value, description, updatedAt: new Date() } });
}

// ─── Dashboard Stats ────────────────────────────────────────────────────────

export async function getDashboardStats() {
  const db = await getDb(); if (!db) return { totalEmployees: 0, totalPayroll: 0, avgSalary: 0, attendanceRate: 0 };
  const empResult = await db.select({ count: sql<number>`count(*)` }).from(employees).where(eq(employees.isActive, 'active'));
  const totalEmployees = empResult[0]?.count || 0;

  const latestPeriod = await db.select().from(payrollPeriods).orderBy(desc(payrollPeriods.period)).limit(1);
  let totalPayroll = 0;
  if (latestPeriod.length > 0) {
    const payrollResult = await db.select({ total: sql<number>`coalesce(sum(${payrollItems.takeHomePay}), 0)` })
      .from(payrollItems).where(eq(payrollItems.payrollPeriodId, latestPeriod[0].id));
    totalPayroll = Number(payrollResult[0]?.total || 0);
  }

  const avgResult = await db.select({ avg: sql<number>`coalesce(avg(${employees.baseSalary}), 0)` })
    .from(employees).where(eq(employees.isActive, 'active'));
  const avgSalary = Number(avgResult[0]?.avg || 0);

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const attResult = await db.select({
    total: sql<number>`count(*)`,
    hadir: sql<number>`coalesce(sum(case when ${attendance.status} = 'hadir' then 1 else 0 end), 0)`
  }).from(attendance).where(and(gte(attendance.date, monthStart), lte(attendance.date, monthEnd)));
  const attendanceRate = attResult[0]?.total ? (Number(attResult[0].hadir) / Number(attResult[0].total)) * 100 : 0;

  return { totalEmployees, totalPayroll, avgSalary, attendanceRate };
}

// ─── Payroll Calculation Engine ─────────────────────────────────────────────

function calculateOvertimeHours(startTime: string, endTime: string): number {
  const [sh, sm] = startTime.split(':').map(Number);
  const [eh, em] = endTime.split(':').map(Number);
  let hours = (eh * 60 + em - sh * 60 - sm) / 60;
  if (hours < 0) hours += 24;
  return Math.round(hours * 100) / 100;
}

export function calculateOvertimePay(
  upahSebulan: number,
  hours: number,
  dayType: 'kerja' | 'libur' | 'besar',
  workDaysPerWeek: number = 5
): number {
  const upahPerJam = upahSebulan / 173;
  let total = 0;
  const h = Math.floor(hours);
  const remainder = hours - h;

  if (dayType === 'kerja') {
    for (let i = 1; i <= h; i++) {
      total += (i === 1 ? 1.5 : 2) * upahPerJam;
    }
    if (remainder > 0) {
      total += (h === 0 ? 1.5 : 2) * upahPerJam * remainder;
    }
  } else if (dayType === 'libur') {
    const threshold = workDaysPerWeek === 6 ? 7 : 8;
    for (let i = 1; i <= h; i++) {
      if (i <= threshold) total += 2 * upahPerJam;
      else if (i === threshold + 1) total += 3 * upahPerJam;
      else total += 4 * upahPerJam;
    }
  } else if (dayType === 'besar') {
    for (let i = 1; i <= h; i++) {
      if (i <= 8) total += 2 * upahPerJam;
      else if (i === 9) total += 3 * upahPerJam;
      else total += 4 * upahPerJam;
    }
  }

  return Math.round(total);
}

export function calculateBPJS(upah: number) {
  const maxUpahKes = 12000000;
  const maxUpahJP = 10547400;
  const bpjsKes = Math.round(Math.min(upah, maxUpahKes) * 0.01);
  const bpjsJHT = Math.round(upah * 0.02);
  const bpjsJP = Math.round(Math.min(upah, maxUpahJP) * 0.01);
  return { bpjsKes, bpjsJHT, bpjsJP, bpjsTkTotal: bpjsJHT + bpjsJP };
}

export function calculatePPh21(
  brutoBulanan: number,
  ptkpStatus: 'TK0' | 'K0' | 'K1' | 'K2' | 'K3',
  iuranPensiunBulanan: number = 0
): number {
  const ptkpMap: Record<string, number> = {
    TK0: 54000000, K0: 58500000, K1: 63000000, K2: 67500000, K3: 72000000,
  };
  const ptkp = ptkpMap[ptkpStatus] || 54000000;

  const brutoTahunan = brutoBulanan * 12;
  const biayaJabatan = Math.min(brutoTahunan * 0.05, 6000000);
  const iuranPensiunTahunan = iuranPensiunBulanan * 12;
  const penghasilanNeto = brutoTahunan - biayaJabatan - iuranPensiunTahunan;
  const pkp = Math.max(0, penghasilanNeto - ptkp);

  let pph21Tahunan = 0;
  const brackets = [
    { limit: 60000000, rate: 0.05 },
    { limit: 250000000, rate: 0.15 },
    { limit: 500000000, rate: 0.25 },
    { limit: 5000000000, rate: 0.30 },
    { limit: Infinity, rate: 0.35 },
  ];
  let remaining = pkp;
  let prevLimit = 0;
  for (const bracket of brackets) {
    if (remaining <= 0) break;
    const taxableInBracket = Math.min(remaining, bracket.limit - prevLimit);
    pph21Tahunan += taxableInBracket * bracket.rate;
    remaining -= taxableInBracket;
    prevLimit = bracket.limit;
  }

  return Math.round(pph21Tahunan / 12);
}

export async function processPayroll(periodId: number) {
  const db = await getDb();
  if (!db) return [];

  const period = await getPayrollPeriodById(periodId);
  if (!period) return [];

  const allEmployees = await db.select().from(employees).where(eq(employees.isActive, 'active'));

  const workDaysPerWeekStr = await getSetting('work_days_per_week');
  const workDaysPerWeek = workDaysPerWeekStr ? parseInt(workDaysPerWeekStr) : 5;

  const [year, month] = period.period.split('-').map(Number);
  const monthStart = new Date(year, month - 1, 1);
  const monthEnd = new Date(year, month, 0);

  await deletePayrollItemsByPeriod(periodId);

  const results: any[] = [];

  for (const emp of allEmployees) {
    const upahSebulan = Number(emp.baseSalary) || 0;

    const attRecords = await db.select().from(attendance)
      .where(and(eq(attendance.employeeId, emp.id), gte(attendance.date, monthStart), lte(attendance.date, monthEnd)));
    const hadirCount = attRecords.filter(a => a.status === 'hadir').length;

    const otRecords = await db.select().from(overtime)
      .where(and(eq(overtime.employeeId, emp.id), gte(overtime.date, monthStart), lte(overtime.date, monthEnd)));

    const shiftRecords = await db.select().from(employeeShifts)
      .where(and(eq(employeeShifts.employeeId, emp.id), gte(employeeShifts.date, monthStart), lte(employeeShifts.date, monthEnd)));

    const empAllowances = await db.select().from(employeeAllowances).where(eq(employeeAllowances.employeeId, emp.id));
    const empDeductions = await db.select().from(employeeDeductions).where(eq(employeeDeductions.employeeId, emp.id));

    let baseSalary = 0;
    let shiftAllowance = 0;
    let overtimePay = 0;

    if (emp.payrollSystem === 'daily') {
      const dailyWage = Number(emp.dailyWage) || 0;
      baseSalary = dailyWage * hadirCount;
    } else if (emp.payrollSystem === 'shift') {
      baseSalary = upahSebulan;
      for (const sr of shiftRecords) {
        const shiftData = await db.select().from(shifts).where(eq(shifts.id, sr.shiftId)).limit(1);
        if (shiftData[0]) {
          shiftAllowance += Number(shiftData[0].shiftIncentive);
        }
      }
    } else {
      baseSalary = upahSebulan;
    }

    for (const ot of otRecords) {
      const otAmount = calculateOvertimePay(upahSebulan, Number(ot.hours), ot.dayType as any, workDaysPerWeek);
      overtimePay += otAmount;
    }

    let totalAllowance = shiftAllowance + overtimePay;
    const allowanceDetails: any[] = [];
    for (const ea of empAllowances) {
      const allowanceData = await db.select().from(allowances).where(eq(allowances.id, ea.allowanceId)).limit(1);
      if (allowanceData[0]) {
        totalAllowance += Number(ea.amount);
        allowanceDetails.push({ name: allowanceData[0].name, amount: Number(ea.amount), taxable: allowanceData[0].isTaxable });
      }
    }

    let totalDeduction = 0;
    const deductionDetails: any[] = [];
    for (const ed of empDeductions) {
      const deductionData = await db.select().from(deductions).where(eq(deductions.id, ed.deductionId)).limit(1);
      if (deductionData[0]) {
        totalDeduction += Number(ed.amount);
        deductionDetails.push({ name: deductionData[0].name, amount: Number(ed.amount) });
      }
    }

    const bpjs = calculateBPJS(upahSebulan);

    const taxableAllowance = allowanceDetails.filter(a => a.taxable === 'yes').reduce((sum, a) => sum + a.amount, 0);
    const brutoBulanan = baseSalary + taxableAllowance + overtimePay;
    const pph21 = calculatePPh21(brutoBulanan, emp.ptkpStatus as any, bpjs.bpjsJP);

    const takeHomePay = baseSalary + totalAllowance - totalDeduction - bpjs.bpjsKes - bpjs.bpjsTkTotal - pph21;

    const details = {
      hadirCount,
      shiftCount: shiftRecords.length,
      overtimeRecords: otRecords.length,
      allowanceDetails,
      deductionDetails,
      payrollSystem: emp.payrollSystem,
    };

    const item = await createPayrollItem({
      payrollPeriodId: periodId,
      employeeId: emp.id,
      baseSalary: baseSalary.toString(),
      shiftAllowance: shiftAllowance.toString(),
      overtimePay: overtimePay.toString(),
      totalAllowance: totalAllowance.toString(),
      totalDeduction: totalDeduction.toString(),
      bpjsKes: bpjs.bpjsKes.toString(),
      bpjsTk: bpjs.bpjsTkTotal.toString(),
      pph21: pph21.toString(),
      takeHomePay: takeHomePay.toString(),
      details,
    });

    results.push(item);
  }

  await updatePayrollPeriod(periodId, { status: 'submitted', processedAt: new Date().toISOString() });

  return results;
}
