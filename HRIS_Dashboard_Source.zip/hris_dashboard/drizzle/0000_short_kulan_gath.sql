CREATE TABLE `allowances` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('fixed','variable') NOT NULL DEFAULT 'fixed',
	`amount` decimal(15,2) NOT NULL DEFAULT '0',
	`isTaxable` enum('yes','no') NOT NULL DEFAULT 'yes',
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `allowances_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`date` timestamp NOT NULL,
	`status` enum('hadir','sakit','izin','cuti','alpha') NOT NULL DEFAULT 'hadir',
	`clockIn` varchar(10),
	`clockOut` varchar(10),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `companies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`address` text,
	`phone` varchar(50),
	`email` varchar(320),
	`npwp` varchar(50),
	`logo` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `companies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `deductions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('fixed','variable') NOT NULL DEFAULT 'fixed',
	`amount` decimal(15,2) NOT NULL DEFAULT '0',
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `deductions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `divisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`code` varchar(20),
	`head` varchar(255),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `divisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employee_allowances` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`allowanceId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `employee_allowances_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employee_deductions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`deductionId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `employee_deductions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employee_shifts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`shiftId` int NOT NULL,
	`date` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `employee_shifts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employees` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nik` varchar(50) NOT NULL,
	`name` varchar(255) NOT NULL,
	`gender` enum('L','P'),
	`birthDate` timestamp,
	`birthPlace` varchar(255),
	`address` text,
	`phone` varchar(50),
	`email` varchar(255),
	`positionId` int,
	`divisionId` int,
	`hireDate` timestamp NOT NULL,
	`resignDate` timestamp,
	`employmentStatus` enum('tetap','kontrak','magang','harian') NOT NULL DEFAULT 'tetap',
	`payrollSystem` enum('daily','shift','monthly') NOT NULL DEFAULT 'monthly',
	`baseSalary` decimal(15,2) NOT NULL DEFAULT '0',
	`dailyWage` decimal(15,2) NOT NULL DEFAULT '0',
	`bpjsKes` varchar(50),
	`bpjsTk` varchar(50),
	`npwp` varchar(50),
	`ptkpStatus` enum('TK0','K0','K1','K2','K3') NOT NULL DEFAULT 'TK0',
	`bank` varchar(100),
	`bankAccount` varchar(50),
	`photo` text,
	`isActive` enum('active','resigned') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `employees_id` PRIMARY KEY(`id`),
	CONSTRAINT `employees_nik_unique` UNIQUE(`nik`)
);
--> statement-breakpoint
CREATE TABLE `overtime` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`date` timestamp NOT NULL,
	`startTime` varchar(10) NOT NULL,
	`endTime` varchar(10) NOT NULL,
	`dayType` enum('kerja','libur','besar') NOT NULL DEFAULT 'kerja',
	`hours` decimal(5,2) NOT NULL DEFAULT '0',
	`amount` decimal(15,2) NOT NULL DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `overtime_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payroll_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`payrollPeriodId` int NOT NULL,
	`employeeId` int NOT NULL,
	`baseSalary` decimal(15,2) NOT NULL DEFAULT '0',
	`shiftAllowance` decimal(15,2) NOT NULL DEFAULT '0',
	`overtimePay` decimal(15,2) NOT NULL DEFAULT '0',
	`totalAllowance` decimal(15,2) NOT NULL DEFAULT '0',
	`totalDeduction` decimal(15,2) NOT NULL DEFAULT '0',
	`bpjsKes` decimal(15,2) NOT NULL DEFAULT '0',
	`bpjsTk` decimal(15,2) NOT NULL DEFAULT '0',
	`pph21` decimal(15,2) NOT NULL DEFAULT '0',
	`takeHomePay` decimal(15,2) NOT NULL DEFAULT '0',
	`details` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payroll_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payroll_periods` (
	`id` int AUTO_INCREMENT NOT NULL,
	`period` varchar(10) NOT NULL,
	`status` enum('draft','submitted','approved','paid') NOT NULL DEFAULT 'draft',
	`processedAt` timestamp,
	`approvedAt` timestamp,
	`paidAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payroll_periods_id` PRIMARY KEY(`id`),
	CONSTRAINT `payroll_periods_period_unique` UNIQUE(`period`)
);
--> statement-breakpoint
CREATE TABLE `positions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`divisionId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`level` varchar(50),
	`baseSalary` decimal(15,2),
	`positionAllowance` decimal(15,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `positions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text NOT NULL,
	`description` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `shifts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`startTime` varchar(10) NOT NULL,
	`endTime` varchar(10) NOT NULL,
	`workDays` varchar(20) NOT NULL DEFAULT '1,2,3,4,5',
	`shiftIncentive` decimal(15,2) NOT NULL DEFAULT '0',
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shifts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
