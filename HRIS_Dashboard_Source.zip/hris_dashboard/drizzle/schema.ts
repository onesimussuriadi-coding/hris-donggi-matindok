import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Company ────────────────────────────────────────────────────────────────

export const companies = mysqlTable("companies", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 320 }),
  npwp: varchar("npwp", { length: 50 }),
  logo: text("logo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Company = typeof companies.$inferSelect;
export type InsertCompany = typeof companies.$inferInsert;

// ─── Division ───────────────────────────────────────────────────────────────

export const divisions = mysqlTable("divisions", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 20 }),
  head: varchar("head", { length: 255 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Division = typeof divisions.$inferSelect;
export type InsertDivision = typeof divisions.$inferInsert;

// ─── Position (Jabatan) ─────────────────────────────────────────────────────

export const positions = mysqlTable("positions", {
  id: int("id").autoincrement().primaryKey(),
  divisionId: int("divisionId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  level: varchar("level", { length: 50 }),
  baseSalary: decimal("baseSalary", { precision: 15, scale: 2 }),
  positionAllowance: decimal("positionAllowance", { precision: 15, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Position = typeof positions.$inferSelect;
export type InsertPosition = typeof positions.$inferInsert;

// ─── Employee (Karyawan) ────────────────────────────────────────────────────

export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  nik: varchar("nik", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  gender: mysqlEnum("gender", ["L", "P"]),
  birthDate: timestamp("birthDate"),
  birthPlace: varchar("birthPlace", { length: 255 }),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 255 }),
  positionId: int("positionId"),
  divisionId: int("divisionId"),
  hireDate: timestamp("hireDate").notNull(),
  resignDate: timestamp("resignDate"),
  employmentStatus: mysqlEnum("employmentStatus", ["tetap", "kontrak", "magang", "harian"]).default("tetap").notNull(),
  payrollSystem: mysqlEnum("payrollSystem", ["daily", "shift", "monthly"]).default("monthly").notNull(),
  baseSalary: decimal("baseSalary", { precision: 15, scale: 2 }).default("0").notNull(),
  dailyWage: decimal("dailyWage", { precision: 15, scale: 2 }).default("0").notNull(),
  bpjsKes: varchar("bpjsKes", { length: 50 }),
  bpjsTk: varchar("bpjsTk", { length: 50 }),
  npwp: varchar("npwp", { length: 50 }),
  ptkpStatus: mysqlEnum("ptkpStatus", ["TK0", "K0", "K1", "K2", "K3"]).default("TK0").notNull(),
  bank: varchar("bank", { length: 100 }),
  bankAccount: varchar("bankAccount", { length: 50 }),
  photo: text("photo"),
  isActive: mysqlEnum("isActive", ["active", "resigned"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

// ─── Shift ──────────────────────────────────────────────────────────────────

export const shifts = mysqlTable("shifts", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  startTime: varchar("startTime", { length: 10 }).notNull(),
  endTime: varchar("endTime", { length: 10 }).notNull(),
  workDays: varchar("workDays", { length: 20 }).default("1,2,3,4,5").notNull(),
  shiftIncentive: decimal("shiftIncentive", { precision: 15, scale: 2 }).default("0").notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Shift = typeof shifts.$inferSelect;
export type InsertShift = typeof shifts.$inferInsert;

export const employeeShifts = mysqlTable("employee_shifts", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  shiftId: int("shiftId").notNull(),
  date: timestamp("date").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmployeeShift = typeof employeeShifts.$inferSelect;

// ─── Attendance & Overtime ──────────────────────────────────────────────────

export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  date: timestamp("date").notNull(),
  status: mysqlEnum("status", ["hadir", "sakit", "izin", "cuti", "alpha"]).default("hadir").notNull(),
  clockIn: varchar("clockIn", { length: 10 }),
  clockOut: varchar("clockOut", { length: 10 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

export const overtime = mysqlTable("overtime", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  date: timestamp("date").notNull(),
  startTime: varchar("startTime", { length: 10 }).notNull(),
  endTime: varchar("endTime", { length: 10 }).notNull(),
  dayType: mysqlEnum("dayType", ["kerja", "libur", "besar"]).default("kerja").notNull(),
  hours: decimal("hours", { precision: 5, scale: 2 }).default("0").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).default("0").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Overtime = typeof overtime.$inferSelect;
export type InsertOvertime = typeof overtime.$inferInsert;

// ─── Allowances & Deductions ────────────────────────────────────────────────

export const allowances = mysqlTable("allowances", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["fixed", "variable"]).default("fixed").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).default("0").notNull(),
  isTaxable: mysqlEnum("isTaxable", ["yes", "no"]).default("yes").notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Allowance = typeof allowances.$inferSelect;
export type InsertAllowance = typeof allowances.$inferInsert;

export const employeeAllowances = mysqlTable("employee_allowances", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  allowanceId: int("allowanceId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmployeeAllowance = typeof employeeAllowances.$inferSelect;

export const deductions = mysqlTable("deductions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["fixed", "variable"]).default("fixed").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).default("0").notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Deduction = typeof deductions.$inferSelect;
export type InsertDeduction = typeof deductions.$inferInsert;

export const employeeDeductions = mysqlTable("employee_deductions", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  deductionId: int("deductionId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmployeeDeduction = typeof employeeDeductions.$inferSelect;

// ─── Payroll ────────────────────────────────────────────────────────────────

export const payrollPeriods = mysqlTable("payroll_periods", {
  id: int("id").autoincrement().primaryKey(),
  period: varchar("period", { length: 10 }).notNull().unique(),
  status: mysqlEnum("status", ["draft", "submitted", "approved", "paid"]).default("draft").notNull(),
  processedAt: timestamp("processedAt"),
  approvedAt: timestamp("approvedAt"),
  paidAt: timestamp("paidAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PayrollPeriod = typeof payrollPeriods.$inferSelect;
export type InsertPayrollPeriod = typeof payrollPeriods.$inferInsert;

export const payrollItems = mysqlTable("payroll_items", {
  id: int("id").autoincrement().primaryKey(),
  payrollPeriodId: int("payrollPeriodId").notNull(),
  employeeId: int("employeeId").notNull(),
  baseSalary: decimal("baseSalary", { precision: 15, scale: 2 }).default("0").notNull(),
  shiftAllowance: decimal("shiftAllowance", { precision: 15, scale: 2 }).default("0").notNull(),
  overtimePay: decimal("overtimePay", { precision: 15, scale: 2 }).default("0").notNull(),
  totalAllowance: decimal("totalAllowance", { precision: 15, scale: 2 }).default("0").notNull(),
  totalDeduction: decimal("totalDeduction", { precision: 15, scale: 2 }).default("0").notNull(),
  bpjsKes: decimal("bpjsKes", { precision: 15, scale: 2 }).default("0").notNull(),
  bpjsTk: decimal("bpjsTk", { precision: 15, scale: 2 }).default("0").notNull(),
  pph21: decimal("pph21", { precision: 15, scale: 2 }).default("0").notNull(),
  takeHomePay: decimal("takeHomePay", { precision: 15, scale: 2 }).default("0").notNull(),
  details: json("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PayrollItem = typeof payrollItems.$inferSelect;
export type InsertPayrollItem = typeof payrollItems.$inferInsert;

// ─── Settings ───────────────────────────────────────────────────────────────

export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;
